create function generate_sequence_if_condition(condition_value text) returns text
    language plpgsql
as
$$
DECLARE
  sequence_value TEXT;
BEGIN
  IF condition_value='ENQUIRY' THEN
    SELECT 'ENQ'|| to_char(nextval('tenant_default.enquiry_no_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='CUSTOMER' THEN
	SELECT 'C'|| to_char(nextval('tenant_default.customer_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='COMPETITOR' THEN
	SELECT 'COM'|| to_char(nextval('tenant_default.competitor_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='EMPLOYEE' THEN
	SELECT 'EMP'|| to_char(nextval('tenant_default.employee_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='ZONE' THEN
	SELECT 'ZN'|| to_char(nextval('tenant_default.zone_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='AGENT' THEN
	SELECT 'A'|| to_char(nextval('tenant_default.agent_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='QUOTATION' THEN
	SELECT 'SPQ'|| to_char(nextval('tenant_default.quotation_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='INSTANTCUSTOMER' THEN
	SELECT 'IC'|| to_char(nextval('tenant_default.instant_customer_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='RATEREQUEST' THEN
	SELECT 'RR'|| to_char(nextval('tenant_default.rate_request_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='SHIPMENT' THEN
	SELECT 'SHP'|| to_char(nextval('tenant_default.shipment_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='SERVICE' THEN
	SELECT to_char(nextval('tenant_default.service_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='DRIVER' THEN
	SELECT 'D'|| to_char(nextval('tenant_default.driver_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='CONTRACTQUOT' THEN
	SELECT 'CON'|| to_char(nextval('tenant_default.contract_quote_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='WAREHOUSE' THEN
	SELECT 'CFS'|| to_char(nextval('tenant_default.warehouse_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='SHIPMENTMASTER' THEN
	SELECT to_char(nextval('tenant_default.shipment_master_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='SAILSCHEDULE' THEN
	SELECT 'SAIL'|| to_char(nextval('tenant_default.sail_schedule_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='AIRLINESHIPMENT' THEN
	SELECT 'AIR'|| to_char(nextval('tenant_default.airline_shipment_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='CFSDELIVERY' THEN
	SELECT 'CFSD'|| to_char(nextval('tenant_default.cfs_delivery_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='HAWB' THEN
	SELECT 'HAWB'|| to_char(nextval('tenant_default.hawb_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='JOBID' THEN
	SELECT to_char(nextval('tenant_default.jobid_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='CONSOLEPLANNER' THEN
	SELECT 'CONS'|| to_char(nextval('tenant_default.console_planner_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='HBL' THEN
	SELECT 'HBL'|| to_char(nextval('tenant_default.hbl_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='MASTERSERVICE' THEN
	SELECT to_char(nextval('tenant_default.master_service_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='DONUMBER' THEN
	SELECT 'DO'|| to_char(nextval('tenant_default.do_number_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='SERVICEMASTERSHIPMENT' THEN
	SELECT 'SMS'|| to_char(nextval('tenant_default.service_master_shipment_uid_id_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='AIRCCN' THEN
	SELECT to_char(nextval('tenant_default.air_ccn_number_seq'), 'FM0000') INTO sequence_value;
  ELSIF condition_value='OCEANCCN' THEN
	SELECT to_char(nextval('tenant_default.ocean_ccn_number_seq'), 'FM0000') INTO sequence_value;
  ELSIF condition_value='AIRTRANSCCN' THEN
	SELECT to_char(nextval('tenant_default.air_trans_ccn_number_seq'), 'FM0000') INTO sequence_value;
  ELSIF condition_value='OCEANTRANSCCN' THEN
	SELECT to_char(nextval('tenant_default.ocean_trans_ccn_number_seq'), 'FM0000') INTO sequence_value;
  ELSIF condition_value='DRAFTDOCNO' THEN
	SELECT to_char(nextval('tenant_default.draft_document_number_seq'), 'FM0000') INTO sequence_value;
  ELSIF condition_value='CRT' THEN
    SELECT 'CRT'|| to_char(nextval('tenant_default.crt_uid_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value = 'TRIP' THEN
    SELECT 'TRIP' || to_char(CURRENT_DATE, 'YYMM') || to_char(nextval('tenant_default.trip_no_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='SUBLEDMASTER' THEN
    SELECT 'SLM'|| to_char(nextval('tenant_default.subledger_master_uid_seq'), 'FM0000000') INTO sequence_value;
   ELSIF condition_value='OPPORTUNITYMASTER' THEN
    SELECT 'OP' || to_char(nextval('tenant_default.opportunity_uid_seq'), 'FM0000000') INTO sequence_value;
  ELSIF condition_value='PRQDOCNO' THEN
	SELECT 'PRQ'|| to_char(nextval('tenant_default.prq_document_number_seq'), 'FM0000') INTO sequence_value;
  ELSE
    sequence_value := -1;
  END IF;
  
  RETURN sequence_value;
END;
$$;

alter function generate_sequence_if_condition(text) owner to dev_user;

