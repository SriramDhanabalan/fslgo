create procedure pro2()
    language plpgsql
as
$$
    begin 

    raise notice 'Hello world';

    end;
  $$;

alter procedure pro2() owner to dev_user;

