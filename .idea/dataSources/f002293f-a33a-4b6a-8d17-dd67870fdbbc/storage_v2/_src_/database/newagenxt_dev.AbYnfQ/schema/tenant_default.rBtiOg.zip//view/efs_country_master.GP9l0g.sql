create view efs_country_master
            (id, code, name, iso3, capital, native, flag, flag_unicode, phone_code, currency_code, region_id, status,
             created_date, created_user, updated_date, updated_user, version)
as
SELECT id,
       code,
       name,
       iso3,
       capital,
       native,
       flag,
       flag_unicode,
       phone_code,
       currency_code,
       region_id,
       status,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version
FROM lookup.efs_country_master;

alter table efs_country_master
    owner to dev_user;

