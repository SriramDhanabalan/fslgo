create view efs_agent_master
            (id, code, name, grade_id, group_id, country_id, status, name_code, created_date, created_user,
             updated_date, updated_user, version, deleted)
as
SELECT id,
       code,
       name,
       grade_id,
       group_id,
       country_id,
       status,
       name_code,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version,
       deleted
FROM lookup.efs_agent_master;

alter table efs_agent_master
    owner to dev_user;

