create view efs_vessel_master
            (id, name, short_name, vessel_country_id, call_sign, imo_number, note, status, created_date, created_user,
             updated_date, updated_user, version, deleted)
as
SELECT id,
       name,
       short_name,
       vessel_country_id,
       call_sign,
       imo_number,
       note,
       status,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version2 AS version,
       deleted
FROM lookup.efs_vessel_master09022024;

alter table efs_vessel_master
    owner to dev_user;

