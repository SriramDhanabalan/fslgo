create view efs_currency_master
            (id, code, name, symbol, country, country_id, created_date, created_user, updated_date, updated_user,
             status, version, currency_suffix, currency_prefix)
as
SELECT id,
       code,
       name,
       symbol,
       country,
       country_id,
       created_date,
       created_user,
       updated_date,
       updated_user,
       status,
       version,
       currency_suffix,
       currency_prefix
FROM lookup.efs_currency_master;

alter table efs_currency_master
    owner to dev_user;

