create view mawb_stock_generation_view(id, carrier_name, branch_id, company_id, stock) as
SELECT carrier_id AS id,
       carrier_name,
       branch_id,
       company_id,
       count(0)   AS stock
FROM mawb_stock_generation
GROUP BY carrier_id, carrier_name, branch_id, company_id;

alter table mawb_stock_generation_view
    owner to dev_user;

