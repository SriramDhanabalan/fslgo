create view master_shipment_list_view
            (id, master_uid, service_name, trade, origin_name, destination_name, arrival, departure, master_status,
             origin_agent_name, destination_agent_name, mawb_or_obl, carrier_vessel_name, voyage_flight_no, branch_id,
             company_id)
as
SELECT DISTINCT aa.id,
                aa.master_uid,
                ss.service_type                                                                                     AS service_name,
                ss.service_trade                                                                                    AS trade,
                aa.origin_name,
                aa.destination_name,
                aa.eta                                                                                              AS arrival,
                aa.etd                                                                                              AS departure,
                aa.status                                                                                           AS master_status,
                bb.origin_agent_name,
                bb.destination_agent_name,
                cc.master_no                                                                                        AS mawb_or_obl,
                string_agg(COALESCE(dd.transporter_name, ((cc.carrier_name::text || '/'::text) ||
                                                          COALESCE(cc.vessel_name, ''::character varying)::text)::character varying)::text,
                ','::text)
                OVER (PARTITION BY aa.id)                                                                           AS carrier_vessel_name,
                string_agg(COALESCE(dd.transport_route_no, cc.route_no)::text, ','::text)
                OVER (PARTITION BY aa.id)                                                                           AS voyage_flight_no,
                ss.branch_id,
                ss.company_id
FROM master_service_detail ss
         JOIN master_header aa ON ss.master_id = aa.id
         JOIN master_party_detail bb ON aa.id = bb.master_id
         JOIN master_carrier_detail cc ON aa.id = cc.master_id
         JOIN master_routing_detail dd ON aa.id = dd.master_id
ORDER BY aa.id;

alter table master_shipment_list_view
    owner to dev_user;

