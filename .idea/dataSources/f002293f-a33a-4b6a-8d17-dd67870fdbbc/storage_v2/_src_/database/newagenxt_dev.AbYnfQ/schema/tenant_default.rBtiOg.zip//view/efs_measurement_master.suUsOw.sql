create view efs_measurement_master
            (id, code, name, header_unit, transport_mode, unit_1, calculation_type_1, calculation_value_1,
             decimal_required_1, round_off_1, system_generated_formula_1, unit_2, calculation_type_2,
             calculation_value_2, decimal_required_2, round_off_2, system_generated_formula_2, status, created_date,
             created_user, updated_date, updated_user, version, deleted)
as
SELECT id,
       code,
       name,
       header_unit,
       transport_mode,
       unit_1,
       calculation_type_1,
       calculation_value_1,
       decimal_required_1,
       round_off_1,
       system_generated_formula_1,
       unit_2,
       calculation_type_2,
       calculation_value_2,
       decimal_required_2,
       round_off_2,
       system_generated_formula_2,
       status,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version,
       deleted
FROM lookup.efs_measurement_master;

alter table efs_measurement_master
    owner to dev_user;

