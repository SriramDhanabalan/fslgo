create procedure aci_emanifest_custom(INOUT fa_status text, IN fa_method text, IN json_input jsonb)
    language plpgsql
as
$$
declare 
lv_name         TEXT; 
lv_id           bigint;
lv_return_id    INTEGER;
lv_page_number  integer;
lv_page_size    integer;
lv_offset_val   integer;
lv_num integer;
begin
lv_id          := json_input->>'id';


if fa_method ='SELECT' then
   lv_page_number := json_input->>'pageNumber';
   lv_page_size   := json_input->>'pageSize';

   select json_agg(hs_code_master)as hs_code_master from(SELECT json_build_object(
    'id', ehcm.id,
    'code', ehcm.code,
    'name', ehcm.name,
    'status', ehcm.status,
    'country', json_build_object(
        'id', ecm.id,
        'code', ecm.code,
        'name', ecm.name
    ),
    'note', ehcm.note,
    'industry', ehcm.industry,
    'createdBy', ehcm.created_user,
    'createdDate', ehcm.created_date,
    'lastModifiedBy', ehcm.updated_user,
    'lastModifiedDate', ehcm.updated_date
) AS hs_code_master
FROM efs_hs_code_master ehcm
     left outer join efs_country_master ecm
     on ehcm.country_id = ecm.id
     ORDER BY ehcm.id
     limit lv_page_size offset lv_offset_val)AS hs_code_master
     into json_input;
elsif lv_id is null then
    INSERT INTO efs_hs_code_master(code,
                                   name,
                                   industry,
                                   status,
                                   note,
                                   country_id,
                                   created_date,
                                   created_user,
                                   updated_date,
                                   updated_user,
                                   version,
                                   deleted)
                            VALUES (json_input->>'code',       -- Extract the "name" field
                                    json_input->>'name',
                                    json_input->>'industry',
                                    json_input->>'status',
                                    json_input->>'note',
                                    (json_input->>'countryId')::INT,
                                    CURRENT_TIMESTAMP,
                                    'Administrator',
                                    CURRENT_TIMESTAMP,
                                    'Administrator',
                                    '0',
                                    'false')
                  RETURNING id INTO lv_return_id;                   
  elsif lv_id is not null then
      update efs_hs_code_master
      set code         = json_input->>'code',
          name         = json_input->>'name',
          industry     = json_input->>'industry',
          status       = json_input->>'status',
          note         = json_input->>'note',
          country_id   = (json_input->>'countryId')::INT,
          updated_date = CURRENT_TIMESTAMP,
          updated_user = 'Administrator'
      where id = lv_id;
      lv_return_id := lv_id;
  end if;  
   fa_status := json_input;--replace(json_input,'"id": null','"id": '||lv_return_id);--'id:'||lv_return_id;

   if fa_method ='SELECT' then
    fa_status := json_input;
   elsif lv_return_id is not null then
    fa_status := replace(fa_status,'"id": null','"id": '||lv_return_id);
   else
    fa_status := 'Error';
   end if;

 --lv_num := 'ul';
END;
$$;

alter procedure aci_emanifest_custom(inout text, text, jsonb) owner to dev_user;

