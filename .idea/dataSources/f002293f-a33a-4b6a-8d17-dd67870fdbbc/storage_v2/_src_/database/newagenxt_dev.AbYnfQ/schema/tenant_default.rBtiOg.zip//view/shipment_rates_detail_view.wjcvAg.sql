create view shipment_rates_detail_view
            (id, version, created_user, created_date, updated_user, updated_date, group_company_id, company_id,
             branch_id, shipment_header_id, shipment_service_id, sl_no, charge_id, charge_name, sell_unit_id, sell_unit,
             currency_id, currency_rate_of_exchange, sell_rate_per_unit, sell_amount, sell_amount_min,
             cost_rate_per_unit, cost_amount, bill_to_customer_id, cost_to_vendor_id, declrated_sell_rate,
             declarted_sell_min, rate_type, rate_reference_type, rate_reference_id, rate_reference_sl_no,
             rate_reference_amount, notes, unit_from, unit_to, cost_unit_id, cost_unit, currency_code, no_of_units,
             cost_currency_id, cost_roe, term, modified, enquiry_ref_charge_id, charge_code, unit_name, unit_code,
             sell_currency_name, sell_currency_code, cost_currency_name, cost_currency_code, bill_to_cust_name,
             bill_to_cust_uid, cost_to_vendor_name, cost_to_vendor_uid, enquiry_no, shipment_uid, service_id,
             service_code, service_name, shipment_id, balance_sell_amt, balance_cost_amt)
as
SELECT aa.id,
       aa.version,
       aa.created_user,
       aa.created_date,
       aa.updated_user,
       aa.updated_date,
       aa.group_company_id,
       aa.company_id,
       aa.branch_id,
       aa.shipment_header_id,
       aa.shipment_service_id,
       aa.sl_no,
       aa.charge_id,
       aa.charge_name,
       aa.sell_unit_id,
       aa.sell_unit,
       aa.currency_id,
       aa.currency_rate_of_exchange,
       aa.sell_rate_per_unit,
       aa.sell_amount,
       aa.sell_amount_min,
       aa.cost_rate_per_unit,
       aa.cost_amount,
       aa.bill_to_customer_id,
       aa.cost_to_vendor_id,
       aa.declrated_sell_rate,
       aa.declarted_sell_min,
       aa.rate_type,
       aa.rate_reference_type,
       aa.rate_reference_id,
       aa.rate_reference_sl_no,
       aa.rate_reference_amount,
       aa.notes,
       aa.unit_from,
       aa.unit_to,
       aa.cost_unit_id,
       aa.cost_unit,
       aa.currency_code,
       aa.no_of_units,
       aa.cost_currency_id,
       aa.cost_roe,
       aa.term,
       aa.modified,
       aa.enquiry_ref_charge_id,
       bb.code         AS charge_code,
       cc.unit_name,
       cc.unit_code,
       dd.name         AS sell_currency_name,
       dd.code         AS sell_currency_code,
       ee.name         AS cost_currency_name,
       ee.code         AS cost_currency_code,
       ff.name         AS bill_to_cust_name,
       ff.customer_uid AS bill_to_cust_uid,
       gg.name         AS cost_to_vendor_name,
       gg.customer_uid AS cost_to_vendor_uid,
       hh.enquiry_no,
       ii.shipment_uid,
       jj.service_id,
       kk.code         AS service_code,
       kk.name         AS service_name,
       ii.id           AS shipment_id,
       aa.balance_sell_amt,
       aa.balance_cost_amt
FROM shipment_rates_detail aa
         LEFT JOIN efs_charge_master bb ON aa.charge_id = bb.id
         LEFT JOIN efs_unit_master cc ON aa.sell_unit_id = cc.id
         LEFT JOIN efs_currency_master dd ON aa.currency_id = dd.id
         LEFT JOIN efs_currency_master ee ON aa.cost_currency_id = ee.id
         LEFT JOIN customer_master ff ON aa.bill_to_customer_id = ff.id
         LEFT JOIN customer_master gg ON aa.cost_to_vendor_id = gg.id
         LEFT JOIN enquiry_header hh ON aa.rate_reference_id = hh.id
         LEFT JOIN shipment_header ii ON aa.shipment_header_id = ii.id
         LEFT JOIN shipment_service_detail jj ON aa.shipment_service_id = jj.id
         LEFT JOIN efs_service_master kk ON jj.service_id = kk.id;

alter table shipment_rates_detail_view
    owner to dev_user;

