create procedure dpa_procedure_customs_new(INOUT fa_status text, IN fa_schema_name character, IN fa_master_id bigint, IN fa_shipment_id bigint)
    language plpgsql
as
$$
declare rec_master record;
declare rec_master_linked record;
declare rec_master_container record;
declare rec_config_header record;
declare rec_shipment_cargo record;

cur_master CURSOR(ca_master_id bigint) FOR 
select 
mh.id,
'VOY' record_identifier,
'' line_code,
'' voyage_agent_code,
mcd.vessel_name,
mcd.route_no voyage,
epm.code port_desc,
to_char(mh.eta,'DD-MON-YYYY')ETA,
mscd.rotation_no ROTATION_NUMBER,
'MFI' message_type,
'' no_of_instalment,
'' agent_manifest_sequence_number,
mh.*
from --tenant_default.master_header mh,
     master_header mh,
     master_carrier_detail mcd,
     master_service_customs_detail mscd,
     efs_port_master epm,
     efs_port_master epm1
where mh.id            = ca_master_id
and mh.destination_id  = epm.id
and mh.origin_id       = epm1.id
and mh.id              = mcd.master_id
and mh.id              = mscd.master_id;

cur_master_linked CURSOR(ca_master_id bigint) FOR 
select master_id,shipment_id,branch_id 
from tenant_default.master_service_link_detail
where master_id = ca_master_id;

cur_master_container CURSOR(ca_master_id bigint,ca_shipment_id bigint) FOR 
select substr(msd.container_number,1,10) container_number,
	   substr(msd.container_number,11,1) check_digit,
       COALESCE(msd.manifest_seal_number,'') seal_no,
       case when ecm.container_type = '20FT'then
       '2.2'
       else '4.4'
       end tare_weight
from tenant_default.master_container_detail msd,
     tenant_default.shipment_container_detail scd,
     lookup.efs_container_master ecm
where msd.master_id = ca_master_id
and scd.shipment_id = ca_shipment_id
and msd.id          = scd.master_container_details_id
and msd.container_id = ecm.id;

cur_config_header cursor(ca_key_name character(100),ca_branch_id bigint) for
select clvd.config_value
from tenant_default.configuration_header ch,
     tenant_default.configuration_link_value_details clvd
where ch.id            = clvd.config_header_id 
and ch.config_key_name = ca_key_name--'Customs Line Code'
and ch.branch_id       = ca_branch_id;

cur_shipment_cargo cursor(ca_shipment_header_id bigint) for
select scdd.no_of_pieces,
       scdd.gross_weight_kgs,
       scdd.volume_weight,
       scdd.chargeable_unit,
       scdd.marks_and_numbers,
       scdd.pack_id,
       scdd.commodity_name,
       scdd.commodity_description,
       epk.code pack_code,
       epk.name pack_name,
       case when upper(scdd.hazardous) = 'YES' then
       'Y'
       else
       'N'
       end dangerous_good
from tenant_default.shipment_cargo_detail scdd
left outer join tenant_default.efs_pack_master epk
on scdd.pack_id = epk.id
where shipment_header_id = ca_shipment_header_id;

lv_line_code        character(100);
lv_agent_code       character(100);
lv_total_container  bigint :=0;   
lv_file_content     text;
begin
    --EXECUTE format('SET search_path TO %I', fa_schema_name);

  for rec_master_linked in cur_master_linked(fa_master_id)
  loop
      rec_master := null;
      open cur_master(rec_master_linked.master_id);
      fetch next from cur_master into rec_master;
      close cur_master;

      rec_config_header := null;
      open cur_config_header('Customs Line Code',rec_master_linked.branch_id);
      fetch next from cur_config_header into rec_config_header;
      close cur_config_header;
      lv_line_code := rec_config_header.config_value;

      rec_config_header := null;
      open cur_config_header('Customs Agent Code',rec_master_linked.branch_id);
      fetch next from cur_config_header into rec_config_header;
      close cur_config_header;
      lv_agent_code := rec_config_header.config_value;


      lv_file_content := '"'||rec_master.record_identifier||'"'||','||'"'||rtrim(lv_line_code)||'"'||','
                         ||'"'||rtrim(lv_agent_code)||'"'||','||'"'||rtrim(rec_master.vessel_name)||'"'||','
                         ||'"'||rtrim(rec_master.voyage)||'"'||','||'"'||rtrim(rec_master.port_desc)||'"'||','
                         ||'"'||rec_master.eta||'"'||','||'"'||rtrim(rec_master.rotation_number)||'"'||','
                         ||'"'||rtrim(rec_master.message_type)||'"'||','||'"'||rtrim(rec_master.no_of_instalment)||'"'||','
                         ||'"'||rec_master.agent_manifest_sequence_number||'"';
      lv_file_content := lv_file_content||'\n';--chr(13);

      for rec_master_container in cur_master_container(rec_master_linked.master_id,rec_master_linked.shipment_id)
      loop
          lv_file_content := lv_file_content
                             ||'"CTR"'||'"'||','||'"'||rec_master_container.container_number||'"'||','
                             ||'"'||rec_master_container.check_digit||'"'||','||'"'||rec_master_container.tare_weight||'"'||','
                             ||'"'||rec_master_container.seal_no||'"'||'\n';--chr(13);

        lv_total_container  := lv_total_container +1;

        rec_shipment_cargo := null;
        open cur_shipment_cargo(rec_master_linked.shipment_id);
        fetch next from cur_shipment_cargo into rec_shipment_cargo;
        close cur_shipment_cargo; 
        lv_file_content := lv_file_content
                           ||'"CON","1",'||'"'||rec_master_container.container_number||'"'||','
                           ||'"'||rec_shipment_cargo.marks_and_numbers||'",'
                           ||'"'||rec_shipment_cargo.commodity_description||'",'
                           ||'"'||''||'",'
                           ||'"'||rec_shipment_cargo.no_of_pieces||'",'
                           ||'"'||rec_shipment_cargo.pack_name||'",'
                           ||'"'||rec_shipment_cargo.pack_code||'",'                           
                           ||'"'||rec_shipment_cargo.no_of_pieces||'",'
                           ||'"'||rec_shipment_cargo.gross_weight_kgs||'",'
                           ||'"'||rec_shipment_cargo.chargeable_unit||'",'
                           ||'"'||rec_shipment_cargo.dangerous_good||'",'
                           ||'"'||rec_shipment_cargo.no_of_pieces||'",'
                           ||'\n';

      end loop;


      --"CON","1","TRHU4911391","USED AUTO PARTS AND COMPLETED  VEHICLES","","770000","1","BOX(S)","BOX","0","23600","50","N","","","","","","","","",""
      lv_file_content := lv_file_content||'"END","'||lv_total_container||'","0","Version No: 1, Product Sr. No: EDI/1.0"';

      delete from tenant_default.dpa_file_content;                                              

      insert into tenant_default.dpa_file_content(file_id,
                                                  file_name,
                                                  file_content)
                                           values(1,
                                                  rec_master.ROTATION_NUMBER,
                                                  lv_file_content);
  end loop;

    fa_status:= '{"Result":"'||replace(lv_file_content,'"','\"')||'"'||'
                 }';
 --fa_status:= '{"Result": "\"VOY\",\"\",\"\",\"FADAK 110\",\"VO78765VO7\",\"AEJEA\",\"04-OCT-2024\",\"RN123456789\",\"MFI\",\"17\",\"00243\""}';
END;
$$;

alter procedure dpa_procedure_customs_new(inout text, char, bigint, bigint) owner to dev_user;

