create view efs_call_type_status_master
            (id, call_type_status, status, note, created_date, created_user, updated_date, updated_user, deleted,
             version, call_type_id)
as
SELECT id,
       call_type_status,
       status,
       note,
       created_date,
       created_user,
       updated_date,
       updated_user,
       deleted,
       version,
       call_type_id
FROM lookup.efs_call_type_status_master;

alter table efs_call_type_status_master
    owner to dev_user;

