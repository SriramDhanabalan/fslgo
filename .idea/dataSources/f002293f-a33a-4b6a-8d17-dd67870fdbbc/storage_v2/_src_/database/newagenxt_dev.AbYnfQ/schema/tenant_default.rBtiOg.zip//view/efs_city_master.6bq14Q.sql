create view efs_city_master
            (id, name, state_id, state_code, country_id, country_code, latitude, longitude, status, created_date,
             created_user, updated_date, updated_user, version)
as
SELECT id,
       name,
       state_id,
       state_code,
       country_id,
       country_code,
       latitude,
       longitude,
       status,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version
FROM lookup.efs_city_master;

alter table efs_city_master
    owner to dev_user;

