create view shipment_view
            (group_company_id, company_id, branch_id, branch, product, shipment_id, shipment_transport_mode_id,
             shipment_service_id, origin_id, destination_id, tos_id, freight_term, customer_id, routed, routed_by_id,
             shipper_id, shipper_name, consignee_id, consignee_name, origin_agent_id, origin_agent_name,
             destination_agent_id, destination_agent_name, pickup_from_id, pickup_from_address_id, hazardous, stackable,
             commodity_id, commodity_name, commodity_description, pack_id, no_of_pieces, gross_weight_kgs,
             gross_weight_lbs, volume_in_cbm, volume_in_cft, volume_weight, chargeable_unit)
as
SELECT shpt_hdr.group_company_id,
       shpt_hdr.company_id,
       shpt_hdr.branch_id,
       branch_m.name             AS branch,
       shpt_srv_dtl.product_code AS product,
       shpt_hdr.shipment_uid     AS shipment_id,
       shpt_hdr.shipment_transport_mode_id,
       shpt_hdr.shipment_service_id,
       shpt_hdr.origin_id,
       shpt_hdr.destination_id,
       shpt_hdr.tos_id,
       shpt_hdr.freight_term,
       shpt_hdr.customer_id,
       shpt_hdr.routed,
       shpt_hdr.routed_by_id,
       shpt_party.shipper_id,
       shipper_m.name            AS shipper_name,
       shpt_party.consignee_id,
       consignee_m.name          AS consignee_name,
       shpt_party.origin_agent_id,
       origin_agent_m.name       AS origin_agent_name,
       shpt_party.destination_agent_id,
       dest_agent_m.name         AS destination_agent_name,
       shpt_pickup_delivery.pickup_from_id,
       shpt_pickup_delivery.pickup_from_address_id,
       shpt_cargo_detail.hazardous,
       shpt_cargo_detail.stackable,
       shpt_cargo_detail.commodity_id,
       shpt_cargo_detail.commodity_name,
       shpt_cargo_detail.commodity_description,
       shpt_cargo_detail.pack_id,
       shpt_cargo_detail.no_of_pieces,
       shpt_cargo_detail.gross_weight_kgs,
       shpt_cargo_detail.gross_weight_lbs,
       shpt_cargo_detail.volume_in_cbm,
       shpt_cargo_detail.volume_in_cft,
       shpt_cargo_detail.volume_weight,
       shpt_cargo_detail.chargeable_unit
FROM efs_group_company_master group_company_m
         JOIN efs_company_master company_m ON group_company_m.id = company_m.group_company_id
         JOIN efs_branch_master branch_m
              ON company_m.group_company_id = branch_m.group_company_id AND company_m.id = branch_m.company_id
         JOIN shipment_header shpt_hdr
              ON branch_m.group_company_id = shpt_hdr.group_company_id AND branch_m.company_id = shpt_hdr.company_id AND
                 branch_m.id = shpt_hdr.branch_id
         LEFT JOIN shipment_service_detail shpt_srv_dtl ON shpt_hdr.id = shpt_srv_dtl.shipment_header_id
         LEFT JOIN shipment_party_detail shpt_party ON shpt_hdr.id = shpt_party.shipment_header_id
         LEFT JOIN shipment_pickup_delivery_detail shpt_pickup_delivery
                   ON shpt_hdr.id = shpt_pickup_delivery.shipment_header_id
         LEFT JOIN shipment_cargo_detail shpt_cargo_detail ON shpt_hdr.id = shpt_cargo_detail.shipment_header_id
         LEFT JOIN efs_service_master shpt_srv ON shpt_srv_dtl.service_id = shpt_srv.id
         LEFT JOIN customer_master customer_m ON shpt_hdr.customer_id = customer_m.id
         LEFT JOIN customer_master shipper_m ON shpt_party.shipper_id = shipper_m.id
         LEFT JOIN customer_master consignee_m ON shpt_party.consignee_id = consignee_m.id
         LEFT JOIN customer_master origin_agent_m ON shpt_party.origin_agent_id = origin_agent_m.id
         LEFT JOIN customer_master dest_agent_m ON shpt_party.destination_agent_id = dest_agent_m.id;

alter table shipment_view
    owner to dev_user;

