create view efs_tos_master
            (id, code, name, status, freight_ppcc, note, created_date, created_user, updated_date, updated_user,
             version, deleted, ranking)
as
SELECT id,
       code,
       name,
       status,
       freight_ppcc,
       note,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version,
       deleted,
       ranking
FROM lookup.efs_tos_master;

alter table efs_tos_master
    owner to dev_user;

