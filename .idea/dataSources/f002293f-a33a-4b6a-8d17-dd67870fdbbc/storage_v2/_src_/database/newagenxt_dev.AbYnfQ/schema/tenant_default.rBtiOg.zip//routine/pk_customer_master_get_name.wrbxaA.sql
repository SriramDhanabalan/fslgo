create function pk_customer_master_get_name(fa_id bigint) returns character varying
    language plpgsql
as
$$
BEGIN
    RETURN (
        SELECT name
        FROM tenant_default.customer_master
        WHERE id = fa_id
    );
END;
$$;

alter function pk_customer_master_get_name(bigint) owner to dev_user;

grant execute on function pk_customer_master_get_name(bigint) to demo_user;

