create function pk_employee_master_get_name(fa_id bigint) returns character varying
    language plpgsql
as
$$
BEGIN
    RETURN (
        SELECT alias_name
        FROM tenant_default.efs_employee_master
        WHERE id = fa_id
    );
END;
$$;

alter function pk_employee_master_get_name(bigint) owner to dev_user;

grant execute on function pk_employee_master_get_name(bigint) to demo_user;

