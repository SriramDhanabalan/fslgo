create view efs_call_type_master (id, name, status, created_date, created_user, updated_date, updated_user, version) as
SELECT id,
       name,
       status,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version
FROM lookup.efs_call_type_master;

alter table efs_call_type_master
    owner to dev_user;

