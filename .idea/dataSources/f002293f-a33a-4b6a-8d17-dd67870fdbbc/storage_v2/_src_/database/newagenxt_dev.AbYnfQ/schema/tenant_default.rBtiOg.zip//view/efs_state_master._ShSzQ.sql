create view efs_state_master
            (id, code, name, country_id, country_code, status, created_date, created_user, updated_date, updated_user,
             version) as
SELECT id,
       code,
       name,
       country_id,
       country_code,
       status,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version
FROM lookup.efs_state_master;

alter table efs_state_master
    owner to dev_user;

