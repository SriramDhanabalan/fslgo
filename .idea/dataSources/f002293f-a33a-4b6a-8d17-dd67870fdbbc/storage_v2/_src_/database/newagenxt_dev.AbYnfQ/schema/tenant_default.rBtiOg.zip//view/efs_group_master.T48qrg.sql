create view efs_group_master
            (id, name, code, status, created_date, created_user, updated_date, updated_user, deleted) as
SELECT id,
       name,
       code,
       status,
       created_date,
       created_user,
       updated_date,
       updated_user,
       deleted
FROM lookup.efs_group_master;

alter table efs_group_master
    owner to dev_user;

