create view efs_zone_master
            (id, code, name, country_id, status, note, created_date, created_user, updated_date, updated_user, version,
             deleted) as
SELECT id,
       code,
       name,
       country_id,
       status,
       note,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version,
       deleted
FROM lookup.efs_zone_master;

alter table efs_zone_master
    owner to dev_user;

