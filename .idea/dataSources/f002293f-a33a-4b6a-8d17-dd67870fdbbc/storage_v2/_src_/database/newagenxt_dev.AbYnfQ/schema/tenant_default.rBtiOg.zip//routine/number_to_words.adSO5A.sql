create function number_to_words(n bigint) returns text
    language plpgsql
as
$$
DECLARE
    Below20 TEXT[] := ARRAY['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 
                            'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 
                            'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    Below100 TEXT[] := ARRAY['Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
BEGIN
    IF n = 0 THEN
        RETURN 'Zero';
    ELSIF n < 0 THEN
        RETURN 'Minus ' || tenant_default.number_to_words(ABS(n));
    ELSIF n < 20 THEN
        RETURN Below20[n + 1];
    ELSIF n < 100 THEN
        RETURN Below100[(n / 10) - 2 + 1] || CASE WHEN n % 10 <> 0 THEN '-' || tenant_default.number_to_words(n % 10) ELSE '' END;
    ELSIF n < 1000 THEN
        RETURN tenant_default.number_to_words(n / 100) || ' Hundred' || 
               CASE WHEN n % 100 <> 0 THEN ' and ' || tenant_default.number_to_words(n % 100) ELSE '' END;
    ELSIF n < 100000 THEN
        RETURN tenant_default.number_to_words(n / 1000) || ' Thousand ' || 
               CASE WHEN n % 1000 <> 0 THEN tenant_default.number_to_words(n % 1000) ELSE '' END;
    ELSIF n < 10000000 THEN
        RETURN tenant_default.number_to_words(n / 100000) || ' Lakh ' || 
               CASE WHEN n % 100000 <> 0 THEN tenant_default.number_to_words(n % 100000) ELSE '' END;
    ELSIF n < 100000000 THEN
        RETURN tenant_default.number_to_words(n / 10000000) || ' Crore ' || 
               CASE WHEN n % 10000000 <> 0 THEN tenant_default.number_to_words(n % 10000000) ELSE '' END;
    ELSIF n < 1000000000 THEN
        RETURN tenant_default.number_to_words(n / 1000000) || ' Million ' || 
               CASE WHEN n % 1000000 <> 0 THEN tenant_default.number_to_words(n % 1000000) ELSE '' END;
    ELSIF n < 1000000000000 THEN
        RETURN tenant_default.number_to_words(n / 1000000000) || ' Billion ' || 
               CASE WHEN n % 1000000000 <> 0 THEN tenant_default.number_to_words(n % 1000000000) ELSE '' END;
    ELSIF n < 1000000000000000 THEN
        RETURN tenant_default.number_to_words(n / 1000000000000) || ' Trillion ' || 
               CASE WHEN n % 1000000000000 <> 0 THEN tenant_default.number_to_words(n % 1000000000000) ELSE '' END;
    ELSE
        RETURN 'Number too large';
    END IF;
END;

$$;

alter function number_to_words(bigint) owner to dev_user;

