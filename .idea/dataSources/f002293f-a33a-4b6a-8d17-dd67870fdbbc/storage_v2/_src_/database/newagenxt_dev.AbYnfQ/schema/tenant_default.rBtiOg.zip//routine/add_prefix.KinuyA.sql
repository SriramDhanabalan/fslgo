create function add_prefix(integer, text) returns text
    immutable
    language sql
as
$$ select $2||to_char($1, 'FM0000000'); $$;

alter function add_prefix(integer, text) owner to dev_user;

