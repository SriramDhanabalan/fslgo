create view efs_container_master
            (id, version, created_user, created_date, updated_user, updated_date, code, name, status, container_type,
             maximum_load_volume, minimum_load_volume, minimum_load_weight, maximum_load_weight, teu, inner_length,
             inner_width, inner_height, outer_length, outer_width, outer_height, empty_tare_weight, note, deleted)
as
SELECT id,
       version,
       created_user,
       created_date,
       updated_user,
       updated_date,
       code,
       name,
       status,
       container_type,
       maximum_load_volume,
       minimum_load_volume,
       minimum_load_weight,
       maximum_load_weight,
       teu,
       inner_length,
       inner_width,
       inner_height,
       outer_length,
       outer_width,
       outer_height,
       empty_tare_weight,
       note,
       deleted
FROM lookup.efs_container_master;

alter table efs_container_master
    owner to dev_user;

