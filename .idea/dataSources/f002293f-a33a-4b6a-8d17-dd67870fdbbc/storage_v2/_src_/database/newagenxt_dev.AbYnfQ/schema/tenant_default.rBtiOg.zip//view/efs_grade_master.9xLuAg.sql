create view efs_grade_master
            (id, name, priority, colour_code, created_date, created_user, updated_date, updated_user, deleted,
             version) as
SELECT id,
       name,
       priority,
       colour_code,
       created_date,
       created_user,
       updated_date,
       updated_user,
       deleted,
       version
FROM lookup.efs_grade_master;

alter table efs_grade_master
    owner to dev_user;

