create view efs_membership_master
            (id, membership_id, membership_name, status, created_date, created_user, updated_date, updated_user,
             deleted, version) as
SELECT id,
       membership_id,
       membership_name,
       status,
       created_date,
       created_user,
       updated_date,
       updated_user,
       deleted,
       version
FROM lookup.efs_membership_master;

alter table efs_membership_master
    owner to dev_user;

