create procedure pro_new_frescon_login_api(IN fa_user_name character varying, IN fa_password character varying, INOUT fa_output text)
    language plpgsql
as
$$
DECLARE
    rec_user RECORD;
    rec_report RECORD;
    rec_report1 RECORD;
    rec_login_cnt RECORD;
    rec_det RECORD;
    lv_json text;
    lv_user_token text;
    i int := 0;
    lv_po text;
    lv_version text;
BEGIN
    -- Fetch user details
    FOR rec_user IN
        SELECT wum.user_id,
               CASE WHEN POSITION(' ' IN wum.name) = 0 THEN
                    replace(wum.name, ' ', '') -- Assuming remove_ascii and replace functions are handled
               ELSE
                    replace(SUBSTRING(wum.name FROM 1 FOR POSITION(' ' IN wum.name) - 1), ' ', '')
               END first_name,
               CASE WHEN POSITION(' ' IN wum.name) = 0 THEN
                    NULL
               ELSE
                    replace(SUBSTRING(wum.name FROM POSITION(' ' IN wum.name) + 1), ' ', '')
               END last_name,
               CASE WHEN POSITION('DEMO' IN wum.user_id) > 0 THEN
                    'webmaster@newage-global.com'
               ELSE
                    CASE WHEN POSITION(';' IN COALESCE(wum.email, cam.email)) = 0 THEN
                        COALESCE(wum.email, cam.email)
                    ELSE
                        SUBSTRING(COALESCE(wum.email, cam.email) FROM 1 FOR POSITION(';' IN COALESCE(wum.email, cam.email)) - 1)
                    END
               END email,
               COALESCE(cam.email, wum.email) toemail,
               replace(COALESCE(wum.address, cam.address), ' ', '') address,
               COALESCE(wum.city, cam.city) city,
               cam.state_name,
               COALESCE(cam.zip_code, cam.po_box) zip_code,
               COALESCE(cam.mobile_no, wum.phone_no) mobile_no,
               cam.fax,
               replace(cm.name, ' ', '') company_name,
               COALESCE(cm.country_code, wud.branch_code) country_code,
               pk_country_master.get_name(COALESCE(wum.country_code, cm.country_code, wud.branch_code)) country_name,
               CASE WHEN wum.is_agent = 'Y' THEN 'true' ELSE 'false' END is_agent,
               NULL image_url,
               wud.customer_code, wum.password_expiry_date, group_account_id,
               wum.bc_code,
               wum.user_type,
               replace(wum.name, ' ', '') name1,
               COALESCE(wum.type, 'NG') type1,
               COALESCE(wum.is_clearance, 'N') is_clearance,
               COALESCE(wum.is_wms, 'N') is_wms,
               COALESCE(wum.is_freight, 'N') is_freight,
               replace(wum.name, ' ', '') accountname,
               COALESCE(wum.is_po, 'N') is_po_customer,
               wum.company_code, wud.branch_code,
               wum.version_code,
               COALESCE(wum.is_our_employee, 'N') is_our_employee,
               COALESCE(wum.is_contracted_cust, 'N') is_contracted_cust,
               pk_currency_master.get_currency_code(COALESCE(cm.country_code, wud.branch_code)) currency_code
        FROM tenant_default.web_user_master wum
        LEFT JOIN tenant_default.web_user_detail wud ON wum.registration_no = wud.registration_no
        LEFT JOIN tenant_default.customer_address_master cam ON wud.customer_code = cam.customer_code AND cam.address_type = 'PRIMARY'
        LEFT JOIN tenant_default.customer_master cm ON wud.customer_code = cm.code
        WHERE wum.user_id = UPPER(fa_user_name)
    LOOP
        -- User token fetch logic
        SELECT sl_no INTO rec_report.sl_no FROM tenant_default.web_report
        WHERE user_id = UPPER(fa_user_name) AND report_type = 'ADMSCRIPT' AND default_value = 'Y'
        ORDER BY sl_no ASC LIMIT 1;

        SELECT sl_no INTO rec_report1.sl_no FROM tenant_default.web_report
        WHERE user_id = UPPER(fa_user_name) AND report_type = 'ADMSCRIPT'
        ORDER BY sl_no ASC LIMIT 1;

        IF rec_report.sl_no IS NOT NULL THEN
            lv_user_token := rec_report.sl_no;
        ELSE
            lv_user_token := rec_report1.sl_no;
        END IF;

        -- Login count logic
        SELECT COUNT(*) INTO rec_login_cnt.cnt FROM tenant_default.frescon_usage_log WHERE user_name = UPPER(fa_user_name);

        -- User details and JSON formation
        IF rec_user.user_id IS NOT NULL AND COALESCE(date_trunc('day', rec_user.password_expiry_date), current_date) >= current_date THEN
            IF rec_user.bc_code IS NOT NULL THEN
                lv_po := 'true';
            ELSE
                lv_po := 'false';
            END IF;

            IF rec_user.version_code = '3.0' THEN
                lv_version := 'V2';
            ELSE
                lv_version := 'V1';
            END IF;

            lv_json := '{"statuscode":"200","statusmessage":"Success","userid":"' || rec_user.user_id || '","usertoken":"' || lv_user_token || '","bccode":"' || rec_user.bc_code || '","type":"' || rec_user.type || '","email":"' || rec_user.email || '","iswms":"' || rec_user.is_wms || '","is_po_customer":"' || rec_user.is_po_customer || '","our_employee":"' || rec_user.is_our_employee || '","isfreight":"' || rec_user.is_freight || '","isclearance":"' || rec_user.is_clearance || '","version":"' || lv_version || '","user_type":"' || rec_user.user_type || '","currency_code":"' || rec_user.currency_code || '","country_name":"' || rec_user.country_name || '","phone_no":"' || rec_user.mobile_no || '","country_code":"' || rec_user.country_code || '","name":"' || rec_user.name || '","company":"' || rec_user.accountname || '","isagent":"' || rec_user.is_agent || '","toEmail":"' || rec_user.toemail || '","equote_link":"https://frescon.freightsystems.com/eQuote/eQuote/BookMe?user_id=' || rec_user.user_id || '&enquiry_type=EFS&customer_code=C977341&company_code=' || rec_user.company_code || '&branch_code=' || rec_user.branch_code || '&location_code=11003&por_country=&por=&fdc_country=&fdc=&&schedule_id=",';

            IF rec_login_cnt.cnt = 0 THEN
                lv_json := lv_json || '"is_first_login":"Y",';
            ELSE
                lv_json := lv_json || '"is_first_login":"N",';
            END IF;

            lv_json := lv_json || '"userdetails":{"name":"' || replace(rec_user.first_name, 'GUEST', '') || '",';
            lv_json := lv_json || '"email":"' || rec_user.email || '","addressline":"' || rec_user.address || '","city":"' || rec_user.city || '","state":"' || rec_user.state_name || '",';
            lv_json := lv_json || '"zipcode":"' || rec_user.zip_code || '","mobile":"' || rec_user.mobile_no || '","fax":"' || rec_user.fax || '","company":"' || rec_user.company_name || '",';
            lv_json := lv_json || '"country":"' || rec_user.country_code || '","country_name":"' || rec_user.country_name || '","isagent":"' || rec_user.is_agent || '","imageurl":"' || rec_user.image_url || '","isPO":"' || lv_po || '","is_contracted_cust":"' || rec_user.is_contracted_cust || '",';
            lv_json := lv_json || '"customer":[';

            -- Fetch customer details
            FOR rec_det IN
                SELECT wud.customer_code, replace(pk_customer_master.get_name(wud.customer_code), ' ', '') customer_name
                FROM tenant_default.web_user_master wum
                JOIN tenant_default.web_user_detail wud ON wum.registration_no = wud.registration_no
                WHERE wum.user_id = UPPER(fa_user_name) AND wud.customer_code IS NOT NULL
            LOOP
                IF i > 0 THEN
                    lv_json := lv_json || ',';
                END IF;
                lv_json := lv_json || '{"code":"' || rec_det.customer_code || '","name":"' || rec_det.customer_name || '"}';
                i := i + 1;
            END LOOP;

            lv_json := lv_json || '],';
            lv_json := lv_json || '"managers":[]}'; -- Placeholder for managers
            lv_json := lv_json || '}}';

            -- Insert login log
            INSERT INTO tenant_default.frescon_usage_log(device_id, user_name, usage_date, process, division_code)
            VALUES (NULL, fa_user_name, current_timestamp, 'LOGIN', NULL);

            -- Update password expiry date
            UPDATE tenant_default.web_user_master SET password_expiry_date = current_timestamp + INTERVAL '90 days' WHERE user_id = fa_user_name;

            COMMIT;
        ELSIF rec_user.user_id IS NULL THEN
            lv_json := '{"statuscode":"201","statusmessage":"Invalid user name or password"}';
        ELSIF date_trunc('day', rec_user.password_expiry_date) < current_date THEN
            lv_json := '{"statuscode":"401","statusmessage":"Password is expired. Please change it immediately"}';
        ELSE
            lv_json := '{"statuscode":"203","statusmessage":"User id is not registered with us. Please check with sales coordinator"}';
        END IF;

        fa_output := lv_json;

        -- Insert XML output
        DELETE FROM tenant_default.gtt_xml;
        INSERT INTO tenant_default.gtt_xml (xml_data) VALUES (fa_output);

        COMMIT;
    END LOOP;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION '-20001, %', SQLERRM;
END;
$$;

alter procedure pro_new_frescon_login_api(varchar, varchar, inout text) owner to dev_user;

