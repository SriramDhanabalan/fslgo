create view job_profitability_view
            (group_company_code, company_code, branch_code, service_code, shipment_uid, charge_code, name, flag,
             amount) as
SELECT egc.code             AS group_company_code,
       ecm.code             AS company_code,
       bm.code              AS branch_code,
       sm.code              AS service_code,
       sh.shipment_uid,
       c.code               AS charge_code,
       c.name,
       'P'::text            AS flag,
       sum(srd.cost_amount) AS amount
FROM shipment_rates_detail srd
         JOIN shipment_header sh ON srd.shipment_header_id = sh.id
         LEFT JOIN efs_charge_master c
                   ON srd.charge_id = c.id AND upper(COALESCE(c.neutral, 'NO'::character varying)::text) = 'NO'::text
         JOIN efs_group_company_master egc ON srd.group_company_id = egc.id
         JOIN efs_company_master ecm ON srd.company_id = ecm.id
         JOIN efs_branch_master bm ON srd.branch_id = bm.id
         LEFT JOIN efs_service_master sm ON srd.shipment_service_id = sm.id
WHERE srd.cost_amount IS NOT NULL
GROUP BY egc.code, ecm.code, bm.code, sm.code, sh.shipment_uid, c.code, c.name
UNION ALL
SELECT egc.code             AS group_company_code,
       ecm.code             AS company_code,
       bm.code              AS branch_code,
       sm.code              AS service_code,
       sh.shipment_uid,
       c.code               AS charge_code,
       c.name,
       'S'::text            AS flag,
       sum(srd.sell_amount) AS amount
FROM shipment_rates_detail srd
         JOIN shipment_header sh ON srd.shipment_header_id = sh.id
         LEFT JOIN efs_charge_master c
                   ON srd.charge_id = c.id AND upper(COALESCE(c.neutral, 'NO'::character varying)::text) = 'NO'::text
         JOIN efs_group_company_master egc ON srd.group_company_id = egc.id
         JOIN efs_company_master ecm ON srd.company_id = ecm.id
         JOIN efs_branch_master bm ON srd.branch_id = bm.id
         LEFT JOIN efs_service_master sm ON srd.shipment_service_id = sm.id
WHERE srd.sell_amount IS NOT NULL
GROUP BY egc.code, ecm.code, bm.code, sm.code, sh.shipment_uid, c.code, c.name
UNION ALL
SELECT egc.code         AS group_company_code,
       ecm.code         AS company_code,
       bm.code          AS branch_code,
       sm.code          AS service_code,
       sh.shipment_uid,
       c.code           AS charge_code,
       c.name,
       'C'::text        AS flag,
       sum(
               CASE
                   WHEN upper(vd.dr_cr::text) = 'DR'::text THEN vd.local_amount
                   ELSE - vd.local_amount
                   END) AS amount
FROM voucher_header vh
         JOIN voucher_detail vd ON vh.id = vd.document_id
         JOIN shipment_header sh ON vd.shipment_header_id = sh.id
         LEFT JOIN efs_charge_master c
                   ON vd.charge_id = c.id AND upper(COALESCE(c.neutral, 'NO'::character varying)::text) = 'NO'::text
         JOIN coa_charge_mapping_master ccm
              ON vd.service_id = ccm.service_id AND vd.charge_id = ccm.charge_id AND vd.account_id = ccm.cost_account_id
         JOIN efs_group_company_master egc ON vh.group_company_id = egc.id
         JOIN efs_company_master ecm ON vh.company_id = ecm.id
         JOIN efs_branch_master bm ON vh.branch_id = bm.id
         LEFT JOIN efs_service_master sm ON vd.service_id = sm.id
WHERE upper(vh.status::text) = 'POSTED'::text
  AND upper(vd.rcn_type::text) = 'S_COST'::text
GROUP BY egc.code, ecm.code, bm.code, sm.code, sh.shipment_uid, c.code, c.name
UNION ALL
SELECT egc.code         AS group_company_code,
       ecm.code         AS company_code,
       bm.code          AS branch_code,
       sm.code          AS service_code,
       sh.shipment_uid,
       c.code           AS charge_code,
       c.name,
       'R'::text        AS flag,
       sum(
               CASE
                   WHEN upper(vd.dr_cr::text) = 'CR'::text THEN vd.local_amount
                   ELSE - vd.local_amount
                   END) AS amount
FROM voucher_header vh
         JOIN voucher_detail vd ON vh.id = vd.document_id
         JOIN shipment_header sh ON vd.shipment_header_id = sh.id
         LEFT JOIN efs_charge_master c
                   ON vd.charge_id = c.id AND upper(COALESCE(c.neutral, 'NO'::character varying)::text) = 'NO'::text
         JOIN coa_charge_mapping_master ccm ON vd.service_id = ccm.service_id AND vd.charge_id = ccm.charge_id AND
                                               vd.account_id = ccm.revenue_account_id
         JOIN efs_group_company_master egc ON vh.group_company_id = egc.id
         JOIN efs_company_master ecm ON vh.company_id = ecm.id
         JOIN efs_branch_master bm ON vh.branch_id = bm.id
         LEFT JOIN efs_service_master sm ON vd.service_id = sm.id
WHERE upper(vh.status::text) = 'POSTED'::text
  AND upper(vd.rcn_type::text) = 'S_REVENUE'::text
GROUP BY egc.code, ecm.code, bm.code, sm.code, sh.shipment_uid, c.code, c.name;

alter table job_profitability_view
    owner to dev_user;

