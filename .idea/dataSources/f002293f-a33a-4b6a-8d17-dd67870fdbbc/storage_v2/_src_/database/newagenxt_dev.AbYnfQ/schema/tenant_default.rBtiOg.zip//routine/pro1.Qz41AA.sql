create procedure pro1()
    language plpgsql
as
$$

    begin 

    raise notice 'Hello world';

    end;
    $$;

alter procedure pro1() owner to dev_user;

