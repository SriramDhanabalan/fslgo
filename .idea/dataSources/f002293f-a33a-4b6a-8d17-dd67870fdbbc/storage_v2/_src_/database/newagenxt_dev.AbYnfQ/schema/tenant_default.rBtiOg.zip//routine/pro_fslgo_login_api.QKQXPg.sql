create procedure pro_fslgo_login_api(IN fa_user_name character varying, IN fa_email_id character varying, IN fa_login_date character varying, IN fa_logout_date character varying, IN fa_ip character varying, IN fa_browser character varying, INOUT fa_output text)
    language plpgsql
as
$$
declare
    lv_json text;
BEGIN
    INSERT INTO fslgo_login (
        create_user,
        create_date,
        run_user,
        run_date,
        email_id,
        login_date,
        logout_date,
        IP,
        Browser
    ) VALUES (
        fa_user_name,
        current_timestamp,
        fa_user_name,
        current_timestamp,
        fa_email_id,
        fa_login_date,
        fa_logout_date,
        fa_IP,
        fa_Browser
    );

    COMMIT;

    lv_json := '{"statuscode":"200","statusmessage":"Success"}';
    fa_output:= lv_json;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error: %', SQLERRM;
END;
$$;

alter procedure pro_fslgo_login_api(varchar, varchar, varchar, varchar, varchar, varchar, inout text) owner to dev_user;

