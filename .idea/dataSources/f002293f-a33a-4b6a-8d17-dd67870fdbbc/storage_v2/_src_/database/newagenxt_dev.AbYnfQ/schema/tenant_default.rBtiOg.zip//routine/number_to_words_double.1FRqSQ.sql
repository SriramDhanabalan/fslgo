create function number_to_words_double(input_value double precision, currency_code character varying) returns text
    language plpgsql
as
$$
DECLARE
    integer_part INT;
    decimal_part INT;
    integer_words TEXT;
    decimal_words TEXT;
    currency_prefix TEXT;
    currency_suffix TEXT;
BEGIN
    -- Fetch currency prefix and suffix from efs_currency_master table based on the 'currency_code' parameter
    SELECT cm.currency_prefix, cm.currency_suffix
    INTO currency_prefix, currency_suffix
    FROM lookup.efs_currency_master cm
    WHERE cm.code = currency_code;

    -- If no currency_prefix or currency_suffix is found, set default values
    IF currency_prefix IS NULL THEN
        currency_prefix := '';
    END IF;

    IF currency_suffix IS NULL THEN
        currency_suffix := '';
    END IF;

    -- Extract integer and decimal parts
    integer_part := FLOOR(input_value);
    decimal_part := ROUND((input_value - integer_part) * 100);

    -- Convert integer part to words
    integer_words := tenant_default.number_to_words(integer_part);

    -- Convert decimal part to words
    IF decimal_part > 0 THEN
        decimal_words := tenant_default.number_to_words(decimal_part);
        RETURN INITCAP(integer_words) || ' ' || currency_prefix || ' and ' || INITCAP(decimal_words) || ' ' || currency_suffix;
    ELSE
        RETURN INITCAP(integer_words) || ' ' || currency_prefix;  -- No decimal part
    END IF;
END;

$$;

alter function number_to_words_double(double precision, varchar) owner to dev_user;

