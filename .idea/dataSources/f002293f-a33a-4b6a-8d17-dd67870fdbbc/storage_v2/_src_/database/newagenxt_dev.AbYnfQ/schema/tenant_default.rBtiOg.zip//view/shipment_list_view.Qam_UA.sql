create view shipment_list_view
            (id, createdby, createddate, lastmodifiedby, lastmodifieddate, service_id, shipment_uid, job_id, branch_id,
             customer_name, shipment_date, status, trade_code, service_type, service_name, origin_id, origin_name,
             destination_name, destination_id, tos_name, routed, freight, creation_mode, created_by, created_date,
             shipper_name, consignee_name, origin_agent, no_of_pieces, total_containers, chargeable_unit,
             gross_weight_kgs, volume_weight, efs_jobno, efs_segment_code, carrier_name, vessel_name,
             voyage_or_flight_no, master_id, cost, revenue, gp, eta, etd, ccn_number, full_groupage, is_service_job,
             planned_pickup_date)
as
SELECT sh.id,
       sh.created_user                                                                                            AS createdby,
       sh.created_date                                                                                            AS createddate,
       sh.updated_user                                                                                            AS lastmodifiedby,
       sh.updated_user                                                                                            AS lastmodifieddate,
       ssd.id                                                                                                     AS service_id,
       sh.shipment_uid,
       ssd.shipment_service_uid                                                                                   AS job_id,
       ssd.branch_id,
       sh.customer_name,
       ssd.service_date                                                                                           AS shipment_date,
       ssd.service_status                                                                                         AS status,
       ssd.service_trade                                                                                          AS trade_code,
       sh.service_type,
       ssd.product_code                                                                                           AS service_name,
       sh.origin_id,
       sh.origin_name,
       sh.destination_name,
       sh.destination_id,
       sh.tos_name,
       sh.routed,
       sh.freight_term                                                                                            AS freight,
       ssd.service_mode                                                                                           AS creation_mode,
       ssd.created_user                                                                                           AS created_by,
       ssd.created_date,
       sp.shipper_name,
       sp.consignee_name,
       cm.name                                                                                                    AS origin_agent,
       sc.no_of_pieces,
       count(DISTINCT scd.id)                                                                                     AS total_containers,
       sc.chargeable_unit,
       sc.gross_weight_kgs,
       sc.volume_weight,
       sad.efs_jobno,
       sad.efs_segment_code,
       ec.name                                                                                                    AS carrier_name,
       ev.name                                                                                                    AS vessel_name,
       sad.planned_route_no                                                                                       AS voyage_or_flight_no,
       mh.master_uid                                                                                              AS master_id,
       round(sum(COALESCE(srd.cost_amount, 0::real) * COALESCE(srd.cost_roe, 0::double precision))::numeric,
             3)                                                                                                   AS cost,
       round(sum(COALESCE(srd.sell_amount, 0::real) *
                 COALESCE(srd.currency_rate_of_exchange, 0::double precision))::numeric,
             3)                                                                                                   AS revenue,
       round((sum(COALESCE(srd.sell_amount, 0::real) * COALESCE(srd.currency_rate_of_exchange, 0::double precision)) -
              sum(COALESCE(srd.cost_amount, 0::real) * COALESCE(srd.cost_roe, 0::double precision)))::numeric, 3) AS gp,
       sad.eta,
       sad.etd,
       sad.ccn_no                                                                                                 AS ccn_number,
       es.full_groupage,
       sad.is_service_job,
       spd.planned_pickup_date
FROM shipment_header sh
         LEFT JOIN shipment_service_detail ssd ON ssd.shipment_header_id = sh.id
         LEFT JOIN shipment_addl_detail sad ON sad.shipment_header_id = sh.id
         LEFT JOIN shipment_pickup_delivery_detail spd ON spd.shipment_header_id = sh.id
         LEFT JOIN shipment_party_detail sp ON sp.shipment_header_id = sh.id
         LEFT JOIN customer_master cm ON sp.origin_agent_id = cm.id
         LEFT JOIN shipment_cargo_detail sc ON sc.shipment_header_id = sh.id
         LEFT JOIN shipment_container_detail scd ON scd.shipment_id = sh.id
         LEFT JOIN efs_carrier_master ec ON sad.planned_carrier_id = ec.id
         LEFT JOIN efs_vessel_master ev ON sad.planned_vessel_id = ev.id
         LEFT JOIN master_service_link_detail msld ON msld.shipment_service_id = ssd.id
         LEFT JOIN master_service_detail msd ON msld.master_service_id = msd.id
         LEFT JOIN master_header mh ON msd.master_id = mh.id
         LEFT JOIN shipment_rates_detail srd ON srd.shipment_header_id = sh.id
         LEFT JOIN efs_service_master es ON ssd.service_id = es.id
GROUP BY sh.id, sh.shipment_uid, sh.customer_name, sh.service_type, sh.origin_id, sh.origin_name, sh.destination_id,
         sh.destination_name, sh.tos_name, sh.routed, sh.freight_term, sp.shipper_name, sp.consignee_name, cm.name,
         sc.no_of_pieces, sc.chargeable_unit, sc.gross_weight_kgs, sc.volume_weight, sad.is_service_job,
         spd.planned_pickup_date, sad.efs_jobno, sad.efs_segment_code, ec.name, ev.name, sad.planned_route_no,
         mh.master_uid, sad.eta, sad.etd, sad.ccn_no, es.full_groupage, ssd.id, sh.created_user, sh.created_date,
         sh.updated_user;

alter table shipment_list_view
    owner to dev_user;

grant delete, insert, references, select, trigger, truncate, update on shipment_list_view to demo_user;

