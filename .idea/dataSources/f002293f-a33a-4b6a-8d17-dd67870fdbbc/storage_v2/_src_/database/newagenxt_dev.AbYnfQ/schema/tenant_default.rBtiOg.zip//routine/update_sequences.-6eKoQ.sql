create function update_sequences() returns void
    language plpgsql
as
$$
DECLARE
sequence_name1 text;
current_value1 bigint;
max_value1 bigint;
table_name text;
fq_table_name text;
seq_schema text;
fq_sequence_name text;
table_exists int;
BEGIN
-- Get all sequences with the naming convention of "table name" followed by "column name" and "_seq" suffix.
FOR sequence_name1, table_name, seq_schema IN
SELECT sequence_name, LEFT(sequence_name,length(sequence_name)-4),sequence_schema
FROM information_schema.sequences
WHERE sequence_name LIKE '%_seq' and sequence_schema = 'tenant_default' order by sequence_name
LOOP
-- Get the current value of the sequence.
	fq_sequence_name := seq_schema || '.' || sequence_name1;
	EXECUTE 'SELECT last_value FROM ' || fq_sequence_name into current_value1;
-- Get the maximum value of the sequence column in the corresponding table.
    --execute 'select trim_substring(' || quote_ident(fq_sequence_name) || ' ,''_id_seq'')' into table_name;
   	RAISE NOTICE 'Table: %', table_name;
   fq_table_name := seq_schema || '.' || table_name;
   table_exists := 0;
   select count(*) FROM pg_catalog.pg_tables WHERE tablename = quote_ident(table_name) and schemaname = quote_ident(seq_schema) into table_exists;
   raise notice 'Table Exists: %',table_exists;     
    IF table_exists > 0 THEN
    	EXECUTE 'SELECT max(id) from ' || fq_table_name into max_value1;

   	 -- If the current value is less than the maximum value, then update the sequence.
   		IF current_value1 < max_value1 THEN
        	execute 'select setval(''' || fq_sequence_name || ''','|| max_value1 || ')';
    		RAISE NOTICE 'Sequence %: % < %', sequence_name1, current_value1, max_value1;
    	END IF;
   end if;
END LOOP;
end;
$$;

alter function update_sequences() owner to dev_user;

