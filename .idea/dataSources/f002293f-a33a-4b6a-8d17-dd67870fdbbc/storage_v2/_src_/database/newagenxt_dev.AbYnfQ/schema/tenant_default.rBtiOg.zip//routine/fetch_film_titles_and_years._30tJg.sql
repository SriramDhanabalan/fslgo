create function fetch_film_titles_and_years(OUT p_title text, OUT p_release_year integer) returns SETOF record
    language plpgsql
as
$$
DECLARE
    film_cursor CURSOR FOR
        SELECT name title, null release_year
        FROM tenant_default.customer_master;
    film_record RECORD;
BEGIN
    -- Open cursor
    OPEN film_cursor;

    -- Fetch rows and return
    LOOP
        FETCH NEXT FROM film_cursor INTO film_record;
        EXIT WHEN NOT FOUND;

        p_title =  film_record.title;
        --p_release_year = film_record.release_year;
        RETURN NEXT;
    END LOOP;

    -- Close cursor
    CLOSE film_cursor;
END;
$$;

alter function fetch_film_titles_and_years(out text, out integer) owner to dev_user;

