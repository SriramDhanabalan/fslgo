create view efs_year_master
            (id, group_company_id, financial_year, start_date, end_date, freeze_date, created_date, created_user,
             updated_date, updated_user, active_inactive, note, version, deleted)
as
SELECT id,
       group_company_id,
       financial_year,
       start_date,
       end_date,
       freeze_date,
       created_date,
       created_user,
       updated_date,
       updated_user,
       active_inactive,
       note,
       version,
       deleted
FROM lookup.efs_year_master;

alter table efs_year_master
    owner to dev_user;

