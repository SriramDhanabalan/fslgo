create view shipment_list_page_view
            (id, customer_name, product_code, shipment_uid, shipment_date, origin_name, destination_name, status,
             branch_id, company_id, group_company_id, version)
as
SELECT aa.id,
       aa.customer_name,
       bb.product_code,
       aa.shipment_uid,
       aa.shipment_date,
       aa.origin_name,
       aa.destination_name,
       aa.status,
       bb.branch_id,
       bb.company_id,
       bb.group_company_id,
       aa.version
FROM shipment_header aa
         LEFT JOIN shipment_service_detail bb ON aa.id = bb.shipment_header_id
         LEFT JOIN transport_document_air cc ON aa.id = cc.source_id
         LEFT JOIN transport_document_ocean dd ON aa.id = dd.source_id
         LEFT JOIN shipment_addl_detail ee ON aa.id = ee.shipment_header_id
         LEFT JOIN shipment_pickup_delivery_detail ff ON aa.id = ff.shipment_header_id
WHERE ee.is_service_job::text = 'No'::text
  AND ee.is_courier_shipment::text = 'No'::text;

alter table shipment_list_page_view
    owner to dev_user;

