create view efs_port_master
            (id, code, name, status, transport_mode, country_code, country_id, created_date, created_user, updated_date,
             updated_user, version, zone_id)
as
SELECT id,
       code,
       name,
       status,
       transport_mode,
       country_code,
       country_id,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version,
       zone_id
FROM lookup.efs_port_master;

alter table efs_port_master
    owner to dev_user;

