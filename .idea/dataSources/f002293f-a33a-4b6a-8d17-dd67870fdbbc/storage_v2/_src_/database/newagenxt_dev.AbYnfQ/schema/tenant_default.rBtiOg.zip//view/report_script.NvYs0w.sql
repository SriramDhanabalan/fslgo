create view report_script
            (id, version, created_user, created_date, updated_user, updated_date, report_script, column_title,
             filter_column, status, report_name)
as
SELECT id,
       version,
       created_user,
       created_date,
       updated_user,
       updated_date,
       report_script,
       column_title,
       filter_column,
       status,
       report_name
FROM lookup.report_script;

alter table report_script
    owner to dev_user;

