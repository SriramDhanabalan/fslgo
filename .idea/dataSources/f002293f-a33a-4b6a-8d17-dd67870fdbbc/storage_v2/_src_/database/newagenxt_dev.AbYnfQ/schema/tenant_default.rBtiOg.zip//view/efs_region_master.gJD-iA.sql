create view efs_region_master
            (id, code, name, status, created_date, created_user, updated_date, updated_user, version) as
SELECT id,
       code,
       name,
       status,
       created_date,
       created_user,
       updated_date,
       updated_user,
       version
FROM lookup.efs_region_master;

alter table efs_region_master
    owner to dev_user;

